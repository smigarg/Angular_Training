(function() {
      'use strict';
angular
	.module('MyNewApp')
	.controller('listController',listCtrl);
	
		listCtrl.$inject = ['$scope'];
		
		
		
		function listCtrl($scope){
			//$scope.values = [];
			var values = [];
			$scope.setColors = setColors;
			$scope.setStates = setStates;
			$scope.getValues = getValues;
			
			
				function setColors(){
					//$scope.values = ["red","blue","green"];
					values = ["red","blue","green"];
				}

				function setStates(){
				
					//$scope.values = ["GUJ","RAJ","KA"];
					values = ["GUJ","RAJ","KA"];
				
				}
			
				function getValues(){
					return values;
				
				
				}
			
		}
		
		
		
		
		
		
		
		
		
})();






