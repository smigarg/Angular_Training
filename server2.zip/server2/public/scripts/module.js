(function(){
'use strict'
angular.module('MyNewApp',[]);
})();