(function() {
      'use strict';
angular
	.module('MyNewApp')
	.controller('listController',listCtrl);
	
	
		listCtrl.$inject = ['$scope','$http','userService','$rootScope'];
		
		
		
		function listCtrl($scope,$http,userService,$rootScope){
			$scope.selectUser = selectUser;
			$http
				.get('./scripts/jsonFile.js')
				.success(function(data){
					$scope.users=data;
				})
				.error(function(err){
					console.log(err);
				});
		
			
			
			function selectUser(user){
				userService.setCurrentUser(user);
				$rootScope.$broadcast("userChanged");
				//console.log(user);
			}
		
		
		
		}
		
		
		
		
		
		
})();






