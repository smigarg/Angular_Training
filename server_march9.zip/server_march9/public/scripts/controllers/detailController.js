(function() {
      'use strict';
angular
	.module('MyNewApp')
	.controller('detailController',detailCtrl);
	
		detailCtrl.$inject = ['$scope','userService'];
		
		function detailCtrl($scope,userService){
			$scope.$on('userChanged',userChanged);
			
				function userChanged(){
					$scope.currentUser=userService.getCurrentUser();
				
			}
			
			
		}
		
		
		
})();






