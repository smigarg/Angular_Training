(function(){
'use strict'
angular
	
	.module('MyNewApp',['ngRoute'])
	.config(router);
	
	
	router.$inject=['$routeProvider'];
	
	function router($routeProvider){
		$routeProvider.when('/',{
			controller : 'listController',
			templateUrl:'./views/home.html'
		});
		
	}
	

	
	
})();