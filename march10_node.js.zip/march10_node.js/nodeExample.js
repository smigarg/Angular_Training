//blocking I/O example

var fs=require('fs');
var contents=fs.readFileSync('jsonFile.js').toString();
console.log(contents);