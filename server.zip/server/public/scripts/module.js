(function(){
'use strict'
angular
		.module('MyApp',['ngRoute'])
		.config(router);
		
		router.$inject=['$routeProvider'];
		
		function router($routeProvider){
			
			$routeProvider.when('/',{
			templateUrl:'./views/home.html'
			});
			
			$routeProvider.when('/info',{
			templateUrl:'./views/info.html'
			});
			
			$routeProvider.when('/Page1',{
			templateUrl:'./views/Page1.html'
			});
			
			$routeProvider.when('/Page2',{
			templateUrl:'./views/Page2.html'
			});
			
			$routeProvider.when('/Page3',{
			templateUrl:'./views/Page3.html'
			});
		}
	
})();