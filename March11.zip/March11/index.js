var express=require('express');
var fs=require('fs');
var path=require('path');
var bodyParser=require('body-parser');
var app=express();


app.use(express.static(path.join(__dirname, 'public')));

/*app.get('/users',function(req,res){
	fs.readFile('myJson.json',function(err,contents){
		var obj=contents.toString();
		res.send(obj);		
	});
	
	

});*/

/*app.get('/name/:id',function(req,res){
	console.log(req.params.id);
	res.send('hello world');
	
});*/

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended:true}));

app.post('/postExample',myFunction);

function myFunction(req,res){
	fs.writeFile('message.txt', JSON.stringify(req.body), function (err) {
		if (err) throw err;
		console.log('It\'s saved!');
	});
	res.send("helooooooooo");
}

app.listen(process.env.PORT || 8080)