(function() {
      'use strict';
angular
	.module('MyNewApp')
	.controller('listController',listCtrl);
	
	
		listCtrl.$inject = ['$scope','$http','userService','$rootScope'];
		
		
		
		function listCtrl($scope,$http,userService,$rootScope){
			$scope.selectUser = selectUser;
			$http
				.get('/name/777')
				.success(function(data){
					$scope.name=data;
				})
				.error(function(err){
					console.log(err);
				});
		
			$http
				.post('/postExample',$scope.name)
				.success(function(data){
					console.log("post is done");
				})
				.error(function(err){
					console.log(err);
				});
			
			function selectUser(user){
				userService.setCurrentUser(user);
				$rootScope.$broadcast("userChanged");
				//console.log(user);
			}
		
		
		
		}
		
		
		
		
		
		
})();






